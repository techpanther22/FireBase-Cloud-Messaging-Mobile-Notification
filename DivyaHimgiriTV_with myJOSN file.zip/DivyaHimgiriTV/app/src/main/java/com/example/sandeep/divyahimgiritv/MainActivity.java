package com.example.sandeep.divyahimgiritv;

import android.graphics.Bitmap;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.KeyEvent;
import android.webkit.WebViewClient;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.mainPage)WebView webView_Mainpage;
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView_Mainpage.canGoBack()) {
            webView_Mainpage.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);


        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        webView_Mainpage.setWebViewClient(new WebViewClient(){
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
              // view.findViewById(R.id.p_bar).setVisibility(View.VISIBLE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                findViewById(R.id.image_loading).setVisibility(View.GONE);
                findViewById(R.id.p_bar).setVisibility(View.INVISIBLE);

                //show webview
                webView_Mainpage.setVisibility(View.VISIBLE);
            }
        });
        // setting the webview client.
        //webView_Mainpage.canGoBack();


        WebSettings webSettings = webView_Mainpage.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView_Mainpage.loadUrl("http://divyahimgiritv.com");





    }


}
