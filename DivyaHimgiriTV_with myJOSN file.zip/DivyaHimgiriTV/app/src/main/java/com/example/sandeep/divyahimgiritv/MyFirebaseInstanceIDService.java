package com.example.sandeep.divyahimgiritv;

import android.app.Service;

import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by sawan on 6/23/2018.
 */

public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {


}
